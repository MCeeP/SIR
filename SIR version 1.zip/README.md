# SIR
Spectral processing software

Currently the GIT is being populated and expanded with instructions.
